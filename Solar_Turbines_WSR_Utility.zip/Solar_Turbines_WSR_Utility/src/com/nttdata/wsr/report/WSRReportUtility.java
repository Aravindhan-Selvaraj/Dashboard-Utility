package com.nttdata.wsr.report;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ntt.data.wsr.report.domain.ConsolidateReport;
import com.ntt.data.wsr.report.domain.Incident;
import com.ntt.data.wsr.report.domain.IncidentAssignmentGroupName;
import com.ntt.data.wsr.report.domain.IndividualReport;
import com.ntt.data.wsr.report.domain.Service_Request;
import com.ntt.data.wsr.report.service.WSRTicketServiceImpl;





public class WSRReportUtility {

	public WSRReportUtility() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws Exception 
	{
		FileInputStream fis = new FileInputStream("C:\\Users\\184759\\Desktop\\Solar_Turbines_WSR_Utility\\Book.xlsx");  		  
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		WSRTicketServiceImpl serviceImpl = new WSRTicketServiceImpl();
		// TODO Auto-generated method stub
		//team name
		Scanner myObj = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("Enter the team name");
	    String teamName = myObj.nextLine();
	    
	    //loading all INC
	    //System.out.println("INCIDENT");
		List<Incident> incident = serviceImpl.getAllIncidents(wb);
//		for (Incident incident2 : incident) {
//			System.out.println(incident2.toString());
//		}
	    
		//loading all SR
	    //System.out.println("Service Request");
		List<Service_Request> servicerequest = serviceImpl.getAllServiceRequests(wb);
//		for (Service_Request servicerequest1 : servicerequest) {
//			System.out.println(servicerequest1.toString());
//		}
		
		
		//fetch INC assignment group name
		Set<String> assigneeNames1=serviceImpl.getIncidentGroupName(incident);
		int a=1;
		Set<String> assigneeNames2 = new HashSet<>();
		String arr[]=new String[assigneeNames1.size()+1];
		for (String agn1 : assigneeNames1) {
		System.out.println(a+" "+agn1);	
		arr[a]=agn1;
		a++;
		}
		
		System.out.println("enter required number to select the assignment group or 0 to submit");
		
		int i;
		do
		{
		Scanner myObj1 = new Scanner(System.in);  
	    System.out.println("Enter the number");
	    i = myObj1.nextInt();
	    if(i!=0)
	    {
	    assigneeNames2.add(arr[i]);
	    }
		}while (i!=0);
		System.out.println(assigneeNames2);
		
		System.out.println("enter the start date and end date (yyyy-MM-dd)");
		Scanner myObj2 = new Scanner(System.in);  
	    String st = myObj2.nextLine();
	    Scanner myObj3 = new Scanner(System.in); 
	    String en = myObj3.nextLine();
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date s=sdf.parse(st);
		Date e=sdf.parse(en);
		
	     //Adding enddate+1
		 Calendar c = Calendar.getInstance();
	     c.setTime(e);
	     c.add(Calendar.DAY_OF_MONTH, 1); 
	     String end1 = sdf.format((Date)c.getTime());
	     Date e1=sdf.parse(end1);
	     System.out.println(e1);
		
	    //incident consolidated
		Map<String, ConsolidateReport> result=serviceImpl.getConsolidatedIncidentReports(incident,assigneeNames2,s,e1);
		for (Map.Entry<String, ConsolidateReport> entry : result.entrySet()) {
		    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
		}
		
		//Service request consolidated
		Map<String, ConsolidateReport> result1=serviceImpl.getConsolidatedServiceRequestReports(servicerequest,assigneeNames2,s,e1);
		for (Map.Entry<String, ConsolidateReport> entry : result1.entrySet()) {
		    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
		}
		
		
		//incident individual count
		Map<String, IndividualReport> reult2=serviceImpl.getIndividualIncidentReports(incident,assigneeNames2, s, e1);
		for (Map.Entry<String,IndividualReport> entry : reult2.entrySet()) {
		    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
		}
		//Set<String> assigneeNames = serviceImpl.getIncidentAssigneeNames(incident,assigneeNames1);
		
		//SR individual count
		Map<String, IndividualReport> reult3=serviceImpl.getIndividualServiceRequestReports(servicerequest,assigneeNames2, s, e1);
		for (Map.Entry<String,IndividualReport> entry : reult3.entrySet()) {
		    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
		}
		
		
	}

}
