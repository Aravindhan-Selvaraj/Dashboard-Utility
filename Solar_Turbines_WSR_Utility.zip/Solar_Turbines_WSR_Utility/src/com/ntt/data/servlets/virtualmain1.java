package com.ntt.data.servlets;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ntt.data.wsr.report.domain.Incident;
import com.ntt.data.wsr.report.domain.Service_Request;
import com.ntt.data.wsr.report.service.WSRTicketServiceImpl;

public class virtualmain1 
{
	
	 public List<Incident> vm1() throws Exception
	{
		
		 	FileInputStream fis = new FileInputStream("C:\\Users\\184759\\Desktop\\Solar_Turbines_WSR_Utility\\Book.xlsx");  		  
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			WSRTicketServiceImpl serviceImpl = new WSRTicketServiceImpl();
			List<Incident> incident = serviceImpl.getAllIncidents(wb);
			
	return incident;
	}
	 
	public List<Service_Request> vm2() throws Exception
		{
			
			 	FileInputStream fis = new FileInputStream("C:\\Users\\184759\\Desktop\\Solar_Turbines_WSR_Utility\\Book.xlsx");  		  
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				WSRTicketServiceImpl serviceImpl = new WSRTicketServiceImpl();
				List<Service_Request> servicerequest = serviceImpl.getAllServiceRequests(wb);
		return servicerequest;
		}
	 
	 
	
}
