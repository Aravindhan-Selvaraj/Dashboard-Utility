package com.ntt.data.servlets;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ntt.data.wsr.report.domain.Incident;
import com.ntt.data.wsr.report.domain.Service_Request;
import com.ntt.data.wsr.report.service.WSRTicketServiceImpl;

public class TeamNameServlet extends HttpServlet
{

	public static  String tn1;

	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
			{
		
			try {
			tn1=req.getParameter("name");
			System.out.println(tn1);		
			PrintWriter out = res.getWriter();
			HttpSession session=req.getSession(true);
			
			virtualmain1 o=new virtualmain1();
			List<Incident> inc=o.vm1();
			List<Service_Request> sr=o.vm2();
			
			WSRTicketServiceImpl serviceImpl = new WSRTicketServiceImpl();
			Set<String> assigneeNames1=serviceImpl.getIncidentGroupName(inc);	
			
			int a=0;
			String arr[]=new String[assigneeNames1.size()+1];
			for (String agn1 : assigneeNames1) {
			System.out.println(a+" "+agn1);	
			arr[a]=agn1;
			a++;
			}
			session.setAttribute("TN", tn1);	
			session.setAttribute("arr", arr);
			RequestDispatcher dispatcher = req.getRequestDispatcher("GroupName.jsp");
			dispatcher.forward(req, res);
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		
			}
	
}
