package com.ntt.data.servlets;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.portable.InputStream;

import com.ntt.data.wsr.report.domain.ConsolidateReport;
import com.ntt.data.wsr.report.domain.Incident;
import com.ntt.data.wsr.report.domain.IndividualReport;
import com.ntt.data.wsr.report.domain.Service_Request;
import com.ntt.data.wsr.report.service.WSRTicketServiceImpl;

/**
 * Servlet implementation class GroupNameServlet
 */
@WebServlet(name = "GroupNameServlet1", urlPatterns = { "/GroupNameServlet1" })
public class GroupNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GroupNameServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try
		{
		Set<String> assigneeNames2 = new HashSet<>();
		String assigneegroupname[]= request.getParameterValues("assigneegroupname");
		System.out.println(assigneegroupname.length);
		for(int i=0;i<assigneegroupname.length;i++)
		{
		assigneeNames2.add(assigneegroupname[i]);
		}
		PrintWriter out = response.getWriter();
		out.println(assigneeNames2);
		
		String st=request.getParameter("startdate");
		String en=request.getParameter("enddate");
		System.out.println(st);
		System.out.println(en);
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date s=sdf.parse(st);
		Date e=sdf.parse(en);
		
		 //Adding startdate-1
		 Calendar c1 = Calendar.getInstance();
	     c1.setTime(s);
	     c1.add(Calendar.DAY_OF_MONTH, -1); 
	     String start1 = sdf.format((Date)c1.getTime());
	     Date s1=sdf.parse(start1);
		
		
	     //Adding enddate+1
		 Calendar c = Calendar.getInstance();
	     c.setTime(e);
	     c.add(Calendar.DAY_OF_MONTH, 1); 
	     String end1 = sdf.format((Date)c.getTime());
	     Date e1=sdf.parse(end1);
	     
			virtualmain1 o=new virtualmain1();
			List<Incident> incident=o.vm1();
			List<Service_Request> servicerequest=o.vm2();
			WSRTicketServiceImpl serviceImpl = new WSRTicketServiceImpl();
			
			
			//consolidated report
			int incidientCount[]=new int[5];
			int serviceRequestCount[]=new int[5];
			TeamNameServlet tn11=new TeamNameServlet();
			String teamname=tn11.tn1;
			System.out.println("Teamname  "+ teamname);

			Properties prop2=new Properties();
			prop2.load(getServletContext().getResourceAsStream("/WEB-INF/assigneeName.properties"));
	
		    //incident consolidated
//			Map<String, ConsolidateReport> resultt=serviceImpl.getConsolidatedIncidentReports(incident,assigneeNames2,s,e1);
//			for (Map.Entry<String, ConsolidateReport> entry : resultt.entrySet()) {
//			    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
//			}
			Map<String, ConsolidateReport> result=serviceImpl.getConsolidatedIncidentReports(incident,assigneeNames2,s1,e1);
			for (Map.Entry<String, ConsolidateReport> entry : result.entrySet()) {
				incidientCount[0]=entry.getValue().getBacklogCount();
			    incidientCount[1]=entry.getValue().getNewCount();
			    incidientCount[2]=entry.getValue().getResolvedCount();
			    incidientCount[3]=entry.getValue().getInProgressCount();
			    incidientCount[4]=entry.getValue().getOnHoldCount();
			    break;
			    
			}
			
			
			
			//Service request consolidated
			Map<String, ConsolidateReport> result1=serviceImpl.getConsolidatedServiceRequestReports(servicerequest,assigneeNames2,s1,e1);
			for (Map.Entry<String, ConsolidateReport> entry : result1.entrySet()) {
			    serviceRequestCount[0]=entry.getValue().getBacklogCount();
			    serviceRequestCount[1]=entry.getValue().getNewCount();
			    serviceRequestCount[2]=entry.getValue().getResolvedCount();
			    serviceRequestCount[3]=entry.getValue().getInProgressCount();
			    serviceRequestCount[4]=entry.getValue().getOnHoldCount();
			    break;
			}
			
			int h1=0;
			int blh=6;
			if(incidientCount[2]>=serviceRequestCount[2])
				h1=incidientCount[2];
			else
				h1=serviceRequestCount[2];
			
			
			
			
			int h2=0;
			if(incidientCount[0]>=serviceRequestCount[0])
				h2=incidientCount[0];			
			else
				h2=serviceRequestCount[0];
			
			if(incidientCount[0]<=20 || serviceRequestCount[0]<=20 )
				blh=10;
			
			if(blh==10)
				h2=h2+20;
			
			int incidentResolvedHeight=3;
			int serviceRequestResolvedHeight=3;
			if(incidientCount[2]<=12)
				incidentResolvedHeight=10;
			if(serviceRequestCount[2]<=12)
				serviceRequestResolvedHeight=10;
			
			
			
			
			
			
			
			System.out.println("h1 and h2");
			System.out.println(incidentResolvedHeight);
			System.out.println(serviceRequestResolvedHeight);
			
			
			
			//incident individual count
			Map<String, IndividualReport> reult2=serviceImpl.getIndividualIncidentReports(incident,assigneeNames2, s1, e1);
			StringBuilder incIndividualResolvedCount= new StringBuilder();
			StringBuilder incIndividualResolvedName= new StringBuilder();
			incIndividualResolvedCount.append("[");
			incIndividualResolvedName.append("[");
			int[] individualResolvedCount=new int[100];
			String[]  individualResolvedName=new String[100];
			int totalIncidentResolvedCount=0;
			int i=0;
			for (Map.Entry<String,IndividualReport> entry : reult2.entrySet()) {
			    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
			    if(entry.getValue().getInProgress()!=0 || entry.getValue().getOnHold()!=0 || entry.getValue().getResolvedCount()!=0)
			    {
			    	if(entry.getKey().equalsIgnoreCase("not assigned"))
			    	{    		
			    	}
			    	else
			    	{
			    		int count=0;
			    		
						    	for(int k=1;k<=10;k++)
						    	{
						    		if(entry.getKey().equalsIgnoreCase(prop2.getProperty("fullName["+k+"]")))
							    	{
							    	count=k;
							    	}
						    	}
						    	if(count!=0)
						    	{
						    	individualResolvedName[i]=prop2.getProperty("name["+count+"]");
						    	individualResolvedCount[i]= entry.getValue().getResolvedCount();
						    	i++;
						    	System.out.println("working");
						    	}else
						    	{
							    	individualResolvedName[i]= entry.getKey().substring(0, entry.getKey().indexOf(" ")); 
							    	individualResolvedCount[i]= entry.getValue().getResolvedCount();
							    	i++;
							    }			    		

			    	}
			    	
			    }
			}
			for(int j=0;j<i;j++)
			{
				incIndividualResolvedCount.append(individualResolvedCount[j]+",");
				incIndividualResolvedName.append("'"+individualResolvedName[j]+"'"+",");
				totalIncidentResolvedCount=totalIncidentResolvedCount+individualResolvedCount[j];
			}
			incIndividualResolvedCount.append(totalIncidentResolvedCount+"]");
			incIndividualResolvedName.append("'Total'"+"]");
			
			
			//Service request individual count
			Map<String, IndividualReport> reult3=serviceImpl.getIndividualServiceRequestReports(servicerequest,assigneeNames2, s1, e1);
			StringBuilder srIndividualResolvedCount= new StringBuilder();
			StringBuilder srIndividualResolvedName= new StringBuilder();
			srIndividualResolvedCount.append("[");
			srIndividualResolvedName.append("[");
			int[] individualServiceRequestResolvedCount=new int[100];
			String[]  individualServiceRequestResolvedName=new String[100];
			int totalServiceRequestResolvedCount=0;
			int i1=0;
			for (Map.Entry<String,IndividualReport> entry : reult3.entrySet()) {
			    System.out.println(entry.getKey() + " : " + entry.getValue().toString());
			    if(entry.getValue().getInProgress()!=0 || entry.getValue().getOnHold()!=0 || entry.getValue().getResolvedCount()!=0)
			    {
			    	if(entry.getKey().equalsIgnoreCase("not assigned"))
			    	{    		
			    	}
			    	else
			    	{
			    		int count=0;
			    		
						    	for(int k=1;k<=10;k++)
						    	{
						    		if(entry.getKey().equalsIgnoreCase(prop2.getProperty("fullName["+k+"]")))
							    	{
							    	count=k;
							    	}
						    	}
						    	if(count!=0)
						    	{
						    		individualServiceRequestResolvedName[i1]=prop2.getProperty("name["+count+"]");
						    		individualServiceRequestResolvedCount[i1]= entry.getValue().getResolvedCount();
						    	i1++;
						    	}else
						    	{
						    		individualServiceRequestResolvedName[i1]= entry.getKey().substring(0, entry.getKey().indexOf(" ")); 
						    		individualServiceRequestResolvedCount[i1]= entry.getValue().getResolvedCount();
							    	i1++;
							    }			    		

			    	}
			    	
			    }
			}
			for(int j=0;j<i1;j++)
			{
				srIndividualResolvedCount.append(individualServiceRequestResolvedCount[j]+",");
				srIndividualResolvedName.append("'"+individualServiceRequestResolvedName[j]+"'"+",");
				totalServiceRequestResolvedCount=totalServiceRequestResolvedCount+individualServiceRequestResolvedCount[j];
			}
			srIndividualResolvedCount.append(totalServiceRequestResolvedCount+"]");
			srIndividualResolvedName.append("'Total'"+"]");
			
			
			
			//incident backlog  inprogress count
			Map<String, IndividualReport> reult4=serviceImpl.getIndividualIncidentReports(incident,assigneeNames2, s1, e1);
				StringBuilder incIndividualInProgressCount= new StringBuilder();
				StringBuilder incIndividualInProgressName= new StringBuilder();
				incIndividualInProgressCount.append("[");
				incIndividualInProgressName.append("[");
				int[] individualInProgressCount=new int[100];
				String[]  individualInProgressName=new String[100];
				int totalIncidentInProgressCount=0;
				int i11=0;
				for (Map.Entry<String,IndividualReport> entry1 : reult4.entrySet()) {
				    if(entry1.getValue().getInProgress()!=0 || entry1.getValue().getOnHold()!=0 || entry1.getValue().getResolvedCount()!=0)
				    {
				    	if(entry1.getKey().equalsIgnoreCase("not assigned"))
				    	{    		
				    	}
				    	else
				    	{
				    		int count=0;
				    		
							    	for(int k=1;k<=10;k++)
							    	{
							    		if(entry1.getKey().equalsIgnoreCase(prop2.getProperty("fullName["+k+"]")))
								    	{
								    	count=k;
								    	}
							    	}
							    	if(count!=0)
							    	{
							    		individualInProgressName[i11]=prop2.getProperty("name["+count+"]");
							    	individualInProgressCount[i11]= entry1.getValue().getInProgress();
							    	i11++;
							    	System.out.println("working");
							    	}else
							    	{
							    		individualInProgressName[i11]= entry1.getKey().substring(0, entry1.getKey().indexOf(" ")); 
							    		individualInProgressCount[i11]= entry1.getValue().getInProgress();
								    	i11++;
								    }			    		

				    	}
				    	
				    }
				}
				for(int j=0;j<i11;j++)
				{
					incIndividualInProgressCount.append(individualInProgressCount[j]+",");
					incIndividualInProgressName.append("'"+individualInProgressName[j]+"'"+",");
					totalIncidentInProgressCount=totalIncidentInProgressCount+individualInProgressCount[j];
				}
				incIndividualInProgressCount.append(totalIncidentInProgressCount+"]");
				incIndividualInProgressName.append("'Total'"+"]");	   

			
			//incident backlog  OnHold count
			Map<String, IndividualReport> reult41=serviceImpl.getIndividualIncidentReports(incident,assigneeNames2, s1, e1);
				StringBuilder incIndividualOnHoldCount= new StringBuilder();
				StringBuilder incIndividualOnHoldName= new StringBuilder();
				incIndividualOnHoldCount.append("[");
				incIndividualOnHoldName.append("[");
				int[] individualOnHoldCount=new int[100];
				String[]  individualOnHoldName=new String[100];
				int totalIncidentOnHoldCount=0;
				int i111=0;
				for (Map.Entry<String,IndividualReport> entry1 : reult41.entrySet()) {
				    if(entry1.getValue().getInProgress()!=0 || entry1.getValue().getOnHold()!=0 || entry1.getValue().getResolvedCount()!=0)
				    {
				    	if(entry1.getKey().equalsIgnoreCase("not assigned"))
				    	{    		
				    	}
				    	else
				    	{
				    		int count=0;
				    		
							    	for(int k=1;k<=10;k++)
							    	{
							    		if(entry1.getKey().equalsIgnoreCase(prop2.getProperty("fullName["+k+"]")))
								    	{
								    	count=k;
								    	}
							    	}
							    	if(count!=0)
							    	{
							    		individualOnHoldName[i111]=prop2.getProperty("name["+count+"]");
							    		individualOnHoldCount[i111]= entry1.getValue().getOnHold();
							    	i111++;
							    	System.out.println("working");
							    	}else
							    	{
							    		individualOnHoldName[i111]= entry1.getKey().substring(0, entry1.getKey().indexOf(" ")); 
							    		individualOnHoldCount[i111]= entry1.getValue().getOnHold();
								    	i111++;
								    }			    		

				    	}
				    	
				    }
				}
				for(int j=0;j<i111;j++)
				{
					incIndividualOnHoldCount.append(individualOnHoldCount[j]+",");
					incIndividualOnHoldName.append("'"+individualOnHoldName[j]+"'"+",");
					totalIncidentOnHoldCount=totalIncidentOnHoldCount+individualOnHoldCount[j];
				}
				incIndividualOnHoldCount.append(totalIncidentOnHoldCount+"]");
				incIndividualOnHoldName.append("'Total'"+"]");	   
			
				
			
				//Service request backlog inprogress count
				Map<String, IndividualReport> reult31=serviceImpl.getIndividualServiceRequestReports(servicerequest,assigneeNames2, s1, e1);
				StringBuilder srIndividualInProgressCount= new StringBuilder();
				StringBuilder srIndividualInProgressName= new StringBuilder();
				srIndividualInProgressCount.append("[");
				srIndividualInProgressName.append("[");
				int[] individualServiceRequestInProgressCount=new int[100];
				String[]  individualServiceRequestInProgressName=new String[100];
				int totalServiceRequestInProgressCount=0;
				int i1111=0;
				for (Map.Entry<String,IndividualReport> entry : reult31.entrySet()) {
				    if(entry.getValue().getInProgress()!=0 || entry.getValue().getOnHold()!=0 || entry.getValue().getResolvedCount()!=0)
				    {
				    	if(entry.getKey().equalsIgnoreCase("not assigned"))
				    	{    		
				    	}
				    	else
				    	{
				    		int count=0;
				    		
							    	for(int k=1;k<=10;k++)
							    	{
							    		if(entry.getKey().equalsIgnoreCase(prop2.getProperty("fullName["+k+"]")))
								    	{
								    	count=k;
								    	}
							    	}
							    	if(count!=0)
							    	{
							    		individualServiceRequestInProgressName[i1111]=prop2.getProperty("name["+count+"]");
							    		individualServiceRequestInProgressCount[i1111]= entry.getValue().getInProgress();
							    	i1111++;
							    	}else
							    	{
							    		individualServiceRequestInProgressName[i1111]= entry.getKey().substring(0, entry.getKey().indexOf(" ")); 
							    		individualServiceRequestInProgressCount[i1111]= entry.getValue().getInProgress();
								    	i1111++;
								    }			    		

				    	}
				    	
				    }
				}
				for(int j=0;j<i1111;j++)
				{
					srIndividualInProgressCount.append(individualServiceRequestInProgressCount[j]+",");
					srIndividualInProgressName.append("'"+individualServiceRequestInProgressName[j]+"'"+",");
					totalServiceRequestInProgressCount=totalServiceRequestInProgressCount+individualServiceRequestInProgressCount[j];
				}
				srIndividualInProgressCount.append(totalServiceRequestInProgressCount+"]");
				srIndividualInProgressName.append("'Total'"+"]");
				
				
				//Service request backlog OnHold count
				Map<String, IndividualReport> reult311=serviceImpl.getIndividualServiceRequestReports(servicerequest,assigneeNames2, s1, e1);
				StringBuilder srIndividualOnHoldCount= new StringBuilder();
				StringBuilder srIndividualOnHoldName= new StringBuilder();
				srIndividualOnHoldCount.append("[");
				srIndividualOnHoldName.append("[");
				int[] individualServiceRequestOnHoldCount=new int[100];
				String[]  individualServiceRequestOnHoldName=new String[100];
				int totalServiceRequestOnHoldCount=0;
				int i11111=0;
				for (Map.Entry<String,IndividualReport> entry : reult311.entrySet()) {
				    if(entry.getValue().getInProgress()!=0 || entry.getValue().getOnHold()!=0 || entry.getValue().getResolvedCount()!=0)
				    {
				    	if(entry.getKey().equalsIgnoreCase("not assigned"))
				    	{    		
				    	}
				    	else
				    	{
				    		int count=0;
				    		
							    	for(int k=1;k<=10;k++)
							    	{
							    		if(entry.getKey().equalsIgnoreCase(prop2.getProperty("fullName["+k+"]")))
								    	{
								    	count=k;
								    	}
							    	}
							    	if(count!=0)
							    	{
							    		individualServiceRequestOnHoldName[i11111]=prop2.getProperty("name["+count+"]");
							    		individualServiceRequestOnHoldCount[i11111]= entry.getValue().getOnHold();
							    	i11111++;
							    	}else
							    	{
							    		individualServiceRequestOnHoldName[i11111]= entry.getKey().substring(0, entry.getKey().indexOf(" ")); 
							    		individualServiceRequestOnHoldCount[i11111]= entry.getValue().getOnHold();
								    	i11111++;
								    }			    		

				    	}
				    	
				    }
				}
				for(int j=0;j<i11111;j++)
				{
					srIndividualOnHoldCount.append(individualServiceRequestOnHoldCount[j]+",");
					srIndividualOnHoldName.append("'"+individualServiceRequestOnHoldName[j]+"'"+",");
					totalServiceRequestOnHoldCount=totalServiceRequestOnHoldCount+individualServiceRequestOnHoldCount[j];
				}
				srIndividualOnHoldCount.append(totalServiceRequestOnHoldCount+"]");
				srIndividualOnHoldName.append("'Total'"+"]");
				
				
				
				
				
				

			
			HttpSession session=request.getSession(true);
			session.setAttribute("h1", h1);
			session.setAttribute("h2", h2);
			session.setAttribute("blh", blh);
			
			session.setAttribute("incidentResolvedHeight", incidentResolvedHeight);
			session.setAttribute("serviceRequestResolvedHeight", serviceRequestResolvedHeight);
		
			session.setAttribute("teamname", teamname);
			session.setAttribute("incidientCount", incidientCount);
			session.setAttribute("serviceRequestCount", serviceRequestCount);
			session.setAttribute("incIndividualResolvedCount", incIndividualResolvedCount);
			session.setAttribute("incIndividualResolvedName", incIndividualResolvedName);
			session.setAttribute("srIndividualResolvedCount", srIndividualResolvedCount);
			session.setAttribute("srIndividualResolvedName", srIndividualResolvedName);
			
			session.setAttribute("incIndividualInProgressCount", incIndividualInProgressCount);
			session.setAttribute("incIndividualInProgressName", incIndividualInProgressName);
			
			session.setAttribute("incIndividualOnHoldCount", incIndividualOnHoldCount);
			session.setAttribute("incIndividualOnHoldName", incIndividualOnHoldName);
			
			session.setAttribute("srIndividualInProgressCount", srIndividualInProgressCount);
			session.setAttribute("srIndividualInProgressName", srIndividualInProgressName);
			
			session.setAttribute("srIndividualOnHoldCount", srIndividualOnHoldCount);
			session.setAttribute("srIndividualOnHoldName", srIndividualOnHoldName);
			
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("chart.jsp");
			dispatcher.forward(request, response);

	     
		}catch(Exception e)
		{
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
