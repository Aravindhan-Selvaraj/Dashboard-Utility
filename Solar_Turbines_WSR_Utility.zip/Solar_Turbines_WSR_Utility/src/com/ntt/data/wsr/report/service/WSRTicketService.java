package com.ntt.data.wsr.report.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ntt.data.wsr.report.domain.ConsolidateReport;
import com.ntt.data.wsr.report.domain.Incident;
import com.ntt.data.wsr.report.domain.IndividualReport;
import com.ntt.data.wsr.report.domain.Service_Request;







public interface WSRTicketService {
	public List<Incident> getAllIncidents(XSSFWorkbook workbook) throws Exception;
	public List<Service_Request> getAllServiceRequests(XSSFWorkbook workbook) throws Exception;
	public List<Map<String,Object>> getAllRecordsFromSheet(String sheetName,XSSFWorkbook workbook) throws Exception;
	public Map<String,ConsolidateReport> getConsolidatedIncidentReports(List<Incident> incidents,Set<String> assignmentGroupName,Date start, Date end) throws Exception;
	public Set<String> getIncidentAssigneeNames(List<Incident> incidents,Set<String> assignmentGroupName) throws Exception;
	public Set<String> getServiceRequestAssigneeNames(List<Service_Request> servicerequest,Set<String> assignmentGroupName) throws Exception;
	public Set<String> getIncidentGroupName(List<Incident> incidents) throws Exception;
	public Map<String,ConsolidateReport> getConsolidatedServiceRequestReports(List<Service_Request> servicerequest,Set<String> assignmentGroupName,Date start, Date end) throws Exception;
	public Map<String,IndividualReport> getIndividualIncidentReports(List<Incident> incidents,Set<String> assignmentGroupName,Date start, Date end) throws Exception;
	public Map<String,IndividualReport> getIndividualServiceRequestReports(List<Service_Request> servicerequest,Set<String> assignmentGroupName,Date start, Date end) throws Exception;
}
