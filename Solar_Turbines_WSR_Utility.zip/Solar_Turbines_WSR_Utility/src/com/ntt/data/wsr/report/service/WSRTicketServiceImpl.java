package com.ntt.data.wsr.report.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ntt.data.wsr.report.domain.ConsolidateReport;
import com.ntt.data.wsr.report.domain.Incident;
import com.ntt.data.wsr.report.domain.IncidentAssignmentGroupName;
import com.ntt.data.wsr.report.domain.IndividualReport;
import com.ntt.data.wsr.report.domain.Service_Request;




public class WSRTicketServiceImpl implements WSRTicketService{

	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	@Override
	public List<Incident> getAllIncidents(XSSFWorkbook workbook) throws Exception 
	{
		
		List<Incident> result = new ArrayList<>();
		List<Map<String, Object>> records = getAllRecordsFromSheet("Incident", workbook);
		for (Map<String, Object> map : records) {
			Incident incident = new Incident();
			for(Map.Entry<String, Object> entry : map.entrySet()) {
				if(entry.getKey().equalsIgnoreCase("number")) {
					incident.setNumber((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("short_description"))
				{
					incident.setShort_description((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("state"))
				{
					incident.setState((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("assigned_to"))
				{
					if((String)entry.getValue()==null)
					{
						incident.setAssigned_to("not assigned");
					}else
					{
					incident.setAssigned_to((String)entry.getValue());
					}
				}else if(entry.getKey().equalsIgnoreCase("assignment_group"))
				{
					incident.setAssignment_group((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("resolved_by"))
				{
					incident.setResolved_by((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("opened_at"))
				{
					Date a=sdf.parse((String) entry.getValue());
					incident.setD_created_date(a);
				}
				else if(entry.getKey().equalsIgnoreCase("resolved_at"))
				{
					if(entry.getValue()==null)
					{
						
						Date b=sdf.parse("1997-01-01 18:10:17");
						incident.setResolved_at(b);
					}else
					{
					Date a=sdf.parse((String)entry.getValue());
					incident.setResolved_at(a);
					}
				}
			}
			result.add(incident);
		}
		return result;


	}

	@Override
	public List<Map<String, Object>> getAllRecordsFromSheet(String sheetName, XSSFWorkbook workbook) throws Exception {
		XSSFSheet sheet = workbook.getSheet(sheetName);
		Iterator<Row> itr = sheet.iterator(); 
		int count = 0;
		List<String> header = new ArrayList<String>();
		List<Map<String,Object>> result = new ArrayList<>();
		while (itr.hasNext())                 
		{  
			Row row = itr.next();
			Map<String,Object> values = new HashMap<>();
			int colIndex = 0;
			Iterator<Cell> cellIterator = row.cellIterator();    
			while (cellIterator.hasNext())   
			{  
				Cell cell = cellIterator.next();
				if(count==0) {
					header.add(cell.getStringCellValue());
				}
				else {
					if(cell.getCellTypeEnum() == CellType.STRING) {
						if(cell.getStringCellValue().equalsIgnoreCase(""))
						{
							values.put(header.get(colIndex), null);
							colIndex++;
						}else
						{
						values.put(header.get(colIndex), cell.getStringCellValue());
						colIndex++;
						}
					} else if(cell.getCellTypeEnum() == CellType.NUMERIC) {
						values.put(header.get(colIndex), cell.getDateCellValue());
						colIndex++;
						
					} else if(cell.getCellTypeEnum() == CellType.BOOLEAN) {
						values.put(header.get(colIndex), cell.getBooleanCellValue());
						colIndex++;
					}
				}

			}  
			count = 1; 
			if(values.size()>0) {
				result.add(values);
			}
		}  
//		for (Map<String, Object> map : result) {
//			System.out.println("Record:"+map.toString());
//		}
		return result;
		
		

	}

	@Override
	public List<Service_Request> getAllServiceRequests(XSSFWorkbook workbook) throws Exception {
		List<Service_Request> result = new ArrayList<>();
		List<Map<String, Object>> records = getAllRecordsFromSheet("Service Request", workbook);
		for (Map<String, Object> map : records) {
			Service_Request servicerequest = new Service_Request();
			for(Map.Entry<String, Object> entry : map.entrySet()) {
			//	System.out.println("Key:"+entry.getKey()+":Value:"+entry.getValue());
				if(entry.getKey().equalsIgnoreCase("number")) {
					servicerequest.setNumber((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("short_description"))
				{
					servicerequest.setShort_description((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("state"))
				{
					servicerequest.setState((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("assigned_to"))
				{
					if((String)entry.getValue()==null)
					{
						servicerequest.setAssigned_to("not assigned");
					}else
					{
						servicerequest.setAssigned_to((String)entry.getValue());
					}	
					
					
				}else if(entry.getKey().equalsIgnoreCase("assignment_group"))
				{
					servicerequest.setAssignment_group((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("closed_by"))
				{
					servicerequest.setClosed_by((String)entry.getValue());
				}else if(entry.getKey().equalsIgnoreCase("opened_at"))
				{
					Date a=sdf.parse((String) entry.getValue());
					servicerequest.setOpened_at(a);
				}
				else if(entry.getKey().equalsIgnoreCase("closed_at"))
				{
					if(entry.getValue()==null)
					{
						Date b=sdf.parse("0000-00-00 18:10:17");
						servicerequest.setClosed_at(b);
					}else
					{
					Date a=sdf.parse((String)entry.getValue());
					servicerequest.setClosed_at(a);
					}
				}
			}
			result.add(servicerequest);
		}
		return result;
		
	}



	@Override
	public Set<String> getIncidentGroupName(List<Incident> incidents) throws Exception {
		// TODO Auto-generated method stub
		Set<String> assigneeNames1 = new HashSet<>();
		for (Incident incident : incidents) {
			assigneeNames1.add(incident.getAssignment_group());
		}
	return assigneeNames1;

	}

	@Override
	public Map<String, ConsolidateReport> getConsolidatedIncidentReports(List<Incident> incidents,
			Set<String> assignmentGroupName, Date start, Date end) throws Exception {
		// TODO Auto-generated method stub
		Map<String, ConsolidateReport> map = new HashedMap<>();
		//System.out.println(start+"........."+end);
		int ip=0;
		int oh=0;
		int bl=0;
		int n=0;
		int r=0;
		ConsolidateReport consolidatereport1= new ConsolidateReport();
		for (String assignmentGroupName1 : assignmentGroupName) 
		{
		ConsolidateReport consolidatereport= new ConsolidateReport();

		List<Incident> inProgressCount = incidents.stream().filter(i ->
		i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getState().equalsIgnoreCase("In Progress")).collect(Collectors.toList());
		if(inProgressCount!=null) {
			consolidatereport.setInProgressCount(inProgressCount.size());
			ip=ip+inProgressCount.size();
			
		}
		
		List<Incident> onHoldCount = incidents.stream().filter(i ->
		i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getState().equalsIgnoreCase("on hold")).collect(Collectors.toList());
		if(onHoldCount!=null) {
			consolidatereport.setOnHoldCount(onHoldCount.size());
			oh=oh+onHoldCount.size();
		}
		
		consolidatereport.setBacklogCount(consolidatereport.getInProgressCount()+consolidatereport.getOnHoldCount());		
	    bl=ip+oh;
		List<Incident> newCount = incidents.stream().filter(i ->
	    i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getD_created_date().after(start)&&i.getD_created_date().before(end)).collect(Collectors.toList());
		if(newCount!=null) {
			consolidatereport.setNewCount(newCount.size());
			n=n+newCount.size();
		}		
		
		List<Incident> resolvedCount = incidents.stream().filter(i ->
		i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getResolved_at().after(start)&&i.getResolved_at().before(end)).collect(Collectors.toList());
		if(resolvedCount!=null) {
			consolidatereport.setResolvedCount(resolvedCount.size());
			r=r+resolvedCount.size();
		}
		
		map.put(assignmentGroupName1, consolidatereport);
		}
		consolidatereport1.setInProgressCount(ip);
		consolidatereport1.setOnHoldCount(oh);
		consolidatereport1.setBacklogCount(bl);
		consolidatereport1.setNewCount(n);
		consolidatereport1.setResolvedCount(r);
		map.put("total", consolidatereport1);
		return map;
		
		
	}

	@Override
	public Map<String, ConsolidateReport> getConsolidatedServiceRequestReports(List<Service_Request> servicerequest,
			Set<String> assignmentGroupName, Date start, Date end) throws Exception {
		// TODO Auto-generated method stub
		Map<String, ConsolidateReport> map = new HashedMap<>();
		//System.out.println(start+"........."+end);
		int ip=0;
		int oh=0;
		int bl=0;
		int n=0;
		int r=0;
		ConsolidateReport consolidatereport1= new ConsolidateReport();
		for (String assignmentGroupName1 : assignmentGroupName) 
		{
		ConsolidateReport consolidatereport= new ConsolidateReport();

		List<Service_Request> inProgressCount = servicerequest.stream().filter(i ->
		i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getState().equalsIgnoreCase("Work in Progress")).collect(Collectors.toList());
		if(inProgressCount!=null) {
			consolidatereport.setInProgressCount(inProgressCount.size());
			ip=ip+inProgressCount.size();
			
		}
		
		List<Service_Request> onHoldCount = servicerequest.stream().filter(i ->
		i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getState().equalsIgnoreCase("Pending")).collect(Collectors.toList());
		if(onHoldCount!=null) {
			consolidatereport.setOnHoldCount(onHoldCount.size());
			oh=oh+onHoldCount.size();
		}
		
		consolidatereport.setBacklogCount(consolidatereport.getInProgressCount()+consolidatereport.getOnHoldCount());		
	    bl=ip+oh;
		List<Service_Request> newCount = servicerequest.stream().filter(i ->
	    i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getOpened_at().after(start)&&i.getClosed_at().before(end)).collect(Collectors.toList());
		if(newCount!=null) {
			consolidatereport.setNewCount(newCount.size());
			n=n+newCount.size();
		}		
		
		List<Service_Request> resolvedCount = servicerequest.stream().filter(i ->
		i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
		i.getClosed_at().after(start)&&i.getClosed_at().before(end)).collect(Collectors.toList());
		if(resolvedCount!=null) {
			consolidatereport.setResolvedCount(resolvedCount.size());
			r=r+resolvedCount.size();
		}
		
		map.put(assignmentGroupName1, consolidatereport);
		}
		consolidatereport1.setInProgressCount(ip);
		consolidatereport1.setOnHoldCount(oh);
		consolidatereport1.setBacklogCount(bl);
		consolidatereport1.setNewCount(n);
		consolidatereport1.setResolvedCount(r);
		map.put("total", consolidatereport1);
		return map;
	}

	@Override
	public Map<String, IndividualReport> getIndividualIncidentReports(List<Incident> incidents,
			Set<String> assignmentGroupName, Date start, Date end) throws Exception {
		// TODO Auto-generated method stub
		Map<String, IndividualReport> result = new HashedMap<>();
		Set<String> assigneeNames = getIncidentAssigneeNames(incidents,assignmentGroupName);
		
		
		
		for (String assigneeName : assigneeNames) 
		{
			int ip=0;
			int oh=0;
			int n=0;
			int r=0;
			IndividualReport individualReport = new IndividualReport();

			for (String assignmentGroupName1 : assignmentGroupName)
			{
				
			List<Incident> inProgress = incidents.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getState().equalsIgnoreCase("in progress")).collect(Collectors.toList());
			if(inProgress!=null) {
				ip=ip+inProgress.size();
				//individualReport.setInProgress(inProgress.size());

			}
				
			List<Incident> onHold = incidents.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getState().equalsIgnoreCase("on hold")).collect(Collectors.toList());
			if(onHold!=null) {
				//individualReport.setOnHold(onHold.size());
				oh=oh+onHold.size();
			}
			individualReport.setInProgress(ip);
			individualReport.setOnHold(oh);
			
			
			List<Incident> new1 = incidents.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getState().equalsIgnoreCase("new")).collect(Collectors.toList());
			if(new1!=null) {
				//individualReport.setOnHold(onHold.size());
				n=n+new1.size();
			}
			
			
			
			List<Incident> resolvedCount = incidents.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getResolved_at().after(start)&&i.getResolved_at().before(end)).collect(Collectors.toList());
			if(resolvedCount!=null) {
				r=r+resolvedCount.size();
			}
			individualReport.setInProgress(ip);
			individualReport.setOnHold(oh);
			individualReport.setNewCount(n);
			individualReport.setResolvedCount(r);
			
			
			
			}
			result.put(assigneeName, individualReport);	
		}
		return result;
		
		
	}

	@Override
	public Set<String> getIncidentAssigneeNames(List<Incident> incidents, Set<String> assignmentGroupName)
			throws Exception {
		// TODO Auto-generated method stub
		Set<String> assigneeNames = new HashSet<>();
		for (String assignmentGroupName1 : assignmentGroupName) 
		{
			for (Incident incident : incidents) {
				if(incident.getAssignment_group().equalsIgnoreCase(assignmentGroupName1))
				{
					
					if(incident.getAssigned_to()==null)
					{
					}else {
					assigneeNames.add(incident.getAssigned_to());
					}
				}
		}
		}
		System.out.println(""+assigneeNames.toString());
		return assigneeNames;
	}

	@Override
	public Map<String, IndividualReport> getIndividualServiceRequestReports(List<Service_Request> servicerequest,
			Set<String> assignmentGroupName, Date start, Date end) throws Exception {
		// TODO Auto-generated method stub
		Map<String, IndividualReport> result = new HashedMap<>();
		Set<String> assigneeNames = getServiceRequestAssigneeNames(servicerequest,assignmentGroupName);
		
		
		
		for (String assigneeName : assigneeNames) 
		{
			int ip=0;
			int oh=0;
			int n=0;
			int r=0;
			IndividualReport individualReport = new IndividualReport();

			for (String assignmentGroupName1 : assignmentGroupName)
			{
				
			List<Service_Request>  inProgress = servicerequest.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getState().equalsIgnoreCase("Work in Progress")).collect(Collectors.toList());
			if(inProgress!=null) {
				ip=ip+inProgress.size();
				//individualReport.setInProgress(inProgress.size());

			}
				
			List<Service_Request> onHold = servicerequest.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getState().equalsIgnoreCase("Pending")).collect(Collectors.toList());
			if(onHold!=null) {
				//individualReport.setOnHold(onHold.size());
				oh=oh+onHold.size();
			}
			individualReport.setInProgress(ip);
			individualReport.setOnHold(oh);
			
			
			List<Service_Request> new1 = servicerequest.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getState().equalsIgnoreCase("open")).collect(Collectors.toList());
			if(new1!=null) {
				//individualReport.setOnHold(onHold.size());
				n=n+new1.size();
			}
			
			
			
			List<Service_Request> resolvedCount = servicerequest.stream().filter(i ->
			i.getAssignment_group().equalsIgnoreCase(assignmentGroupName1)&&
			i.getAssigned_to().equalsIgnoreCase(assigneeName)&&
					i.getClosed_at().after(start)&&i.getClosed_at().before(end)).collect(Collectors.toList());
			if(resolvedCount!=null) {
				r=r+resolvedCount.size();
			}
			individualReport.setInProgress(ip);
			individualReport.setOnHold(oh);
			individualReport.setNewCount(n);
			individualReport.setResolvedCount(r);
			
			
			
			}
			result.put(assigneeName, individualReport);	
		}
		return result;
		
	}

	@Override
	public Set<String> getServiceRequestAssigneeNames(List<Service_Request> servicerequest,
			Set<String> assignmentGroupName) throws Exception {
		// TODO Auto-generated method stub
		Set<String> assigneeNames = new HashSet<>();
		for (String assignmentGroupName1 : assignmentGroupName) 
		{
			for (Service_Request servicerequest1 : servicerequest) {
				if(servicerequest1.getAssignment_group().equalsIgnoreCase(assignmentGroupName1))
				{
					
					if(servicerequest1.getAssigned_to()==null)
					{
					}else {
					assigneeNames.add(servicerequest1.getAssigned_to());
					}
				}
		}
		}
		System.out.println(""+assigneeNames.toString());
		return assigneeNames;
	}

	


	
		
	

}
