package com.ntt.data.wsr.report.domain;

import java.util.Date;

public class Service_Request {

	private String number;
	private String short_description;
	private String state;
	private String assigned_to;
	private String assignment_group;
	private String closed_by;
	private Date opened_at;
	private Date closed_at;
	public String getNumber() {
		return number;
	}
	public  void setNumber(String number) {
		this.number = number;
	}
	public String getShort_description() {
		return short_description;
	}
	public void setShort_description(String short_description) {
		this.short_description = short_description;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAssigned_to() {
		return assigned_to;
	}
	public void setAssigned_to(String assigned_to) {
		this.assigned_to = assigned_to;
	}
	public String getAssignment_group() {
		return assignment_group;
	}
	public void setAssignment_group(String assignment_group) {
		this.assignment_group = assignment_group;
	}
	public String getClosed_by() {
		return closed_by;
	}
	public void setClosed_by(String closed_by) {
		this.closed_by = closed_by;
	}
	public Date getOpened_at() {
		return opened_at;
	}
	public void setOpened_at(Date opened_at) {
		this.opened_at = opened_at;
	}
	public Date getClosed_at() {
		return closed_at;
	}
	public void setClosed_at(Date closed_at) {
		this.closed_at = closed_at;
	}
	@Override
	public String toString() {
		return "Service_Request [number=" + number + ", short_description=" + short_description + ", state=" + state
				+ ", assigned_to=" + assigned_to + ", assignment_group=" + assignment_group + ", closed_by=" + closed_by
				+ ", opened_at=" + opened_at + ", closed_at=" + closed_at + "]";
	}
	
	
}
