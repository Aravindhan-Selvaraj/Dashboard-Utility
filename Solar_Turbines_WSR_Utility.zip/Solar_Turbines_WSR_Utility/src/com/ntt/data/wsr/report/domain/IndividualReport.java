package com.ntt.data.wsr.report.domain;

public class IndividualReport {
	
	private int newCount;
	private int inProgress;
	private int onHold;
	private int resolvedCount;
	public int getResolvedCount() {
		return resolvedCount;
	}
	public void setResolvedCount(int resolvedCount) {
		this.resolvedCount = resolvedCount;
	}

	@Override
	public String toString() {
		return "IndividualReport [newCount=" + newCount + ", inProgress=" + inProgress + ", onHold=" + onHold
				+ ", resolvedCount=" + resolvedCount + "]";
	}
	public int getInProgress() {
		return inProgress;
	}
	public void setInProgress(int inProgress) {
		this.inProgress = inProgress;
	}
	public int getOnHold() {
		return onHold;
	}
	public void setOnHold(int onHold) {
		this.onHold = onHold;
	}
	public int getNewCount() {
		return newCount;
	}
	public void setNewCount(int newCount) {
		this.newCount = newCount;
	}
	
	

}
