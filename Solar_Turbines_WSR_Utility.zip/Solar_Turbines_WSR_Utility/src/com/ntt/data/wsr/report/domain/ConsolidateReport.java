package com.ntt.data.wsr.report.domain;

public class ConsolidateReport {

	private int backlogCount;
	private int newCount;
	private int resolvedCount;
	private int inProgressCount;
	private int onHoldCount;
	@Override
	public String toString() {
		return "ConsolidateReport [backlogCount=" + backlogCount + ", newCount=" + newCount + ", resolvedCount="
				+ resolvedCount + ", inProgressCount=" + inProgressCount + ", onHoldCount=" + onHoldCount + "]";
	}
	//private 
	public int getBacklogCount() {
		return backlogCount;
	}
	public void setBacklogCount(int backlogCount) {
		this.backlogCount = backlogCount;
	}
	public int getNewCount() {
		return newCount;
	}
	public void setNewCount(int newCount) {
		this.newCount = newCount;
	}
	public int getResolvedCount() {
		return resolvedCount;
	}
	public void setResolvedCount(int resolvedCount) {
		this.resolvedCount = resolvedCount;
	}
	public int getInProgressCount() {
		return inProgressCount;
	}
	public void setInProgressCount(int inProgressCount) {
		this.inProgressCount = inProgressCount;
	}
	public int getOnHoldCount() {
		return onHoldCount;
	}
	public void setOnHoldCount(int onHoldCount) {
		this.onHoldCount = onHoldCount;
	}
	
}
