package com.ntt.data.wsr.report.domain;

public class IncidentAssignmentGroupName {


		private String assignmentGroupName;

		public String getAssignmentGroupName() {
			return assignmentGroupName;
		}

		public void setAssignmentGroupName(String assignmentGroupName) {
			this.assignmentGroupName = assignmentGroupName;
		}

		@Override
		public String toString() {
			return "IncidentAssignmentGroupName [assignmentGroupName=" + assignmentGroupName + "]";
		}


}
