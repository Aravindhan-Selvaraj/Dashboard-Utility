package com.ntt.data.wsr.report.domain;

import java.util.Date;

public class Incident {

	private String number;
	private String short_description;
	private String state;
	private String assigned_to;
	private String assignment_group;
	private String resolved_by;
	private Date d_created_date;
	private Date resolved_at;
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getShort_description() {
		return short_description;
	}
	public void setShort_description(String short_description) {
		this.short_description = short_description;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAssigned_to() {
		return assigned_to;
	}
	public void setAssigned_to(String assigned_to) {
		this.assigned_to = assigned_to;
	}
	public String getAssignment_group() {
		return assignment_group;
	}
	public void setAssignment_group(String assignment_group) {
		this.assignment_group = assignment_group;
	}
	public String getResolved_by() {
		return resolved_by;
	}
	public void setResolved_by(String resolved_by) {
		this.resolved_by = resolved_by;
	}
	public Date getD_created_date() {
		return d_created_date;
	}
	public void setD_created_date(Date d_created_date) {
		this.d_created_date = d_created_date;
	}
	public Date getResolved_at() {
		return resolved_at;
	}
	public void setResolved_at(Date resolved_at) {
		this.resolved_at = resolved_at;
	}
	@Override
	public String toString() {
		return "Incident [number=" + number + ", short_description=" + short_description + ", state=" + state
				+ ", assigned_to=" + assigned_to + ", assignment_group=" + assignment_group + ", resolved_by="
				+ resolved_by + ", d_created_date=" + d_created_date + ", resolved_at=" + resolved_at + "]";
	}

	
}
